import hashlib
string="hellow world 277"
encoded=string.encode()
result = hashlib.sha256(encoded)
print("string:", end="")
print(string)
print("Hash Value:",end="")
print(result)
print("hexaDecimal equivalent: " , result.hexdigest())
print("Dizest Size:",end="")
print(result.digest_size)
print("Block Size:",end="")
print(result.block_size)
